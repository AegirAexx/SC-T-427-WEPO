# Bubblify server

## Installation
Start by running npm install to install all the dependencies.

## Run server
The server is run by running npm start or node index.js

## Documentation
All documentation reside in http://localhost:3500/docs
