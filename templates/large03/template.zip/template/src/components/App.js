import React from 'react';

const App = () => {
    return <p>Start working here!</p>
};

export default App;
